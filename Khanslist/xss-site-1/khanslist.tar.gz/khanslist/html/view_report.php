<?php
session_start();
if (!isset($_SESSION['userid'])) {
	header('Location: /login.php?msg_type=error&msg=RAWR%20NOT%20LOGGED%20IN');
	die();
}
if (!$_SESSION['admin']) {
	header('Location: /login.php?msg_type=error&msg=RAWR%20NOT%20AN%20ADMIN');
	die();
}
$include_functions = True;
require_once('functions.php');
$categories = get_categories();

$report = get_report($_GET['report_id']);
if (isset($_GET['action'])) {
	if($_GET['action'] == 'remove') {
		remove_listing($_GET['report_id']);
		header('Location: /admin.php');
	}
}

$page = 'admin';
require __DIR__. '/../vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/../templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('view_report.html', ['session_data' => $_SESSION, 'categories' => $categories, 'page' => $page, 'report' => $report]);