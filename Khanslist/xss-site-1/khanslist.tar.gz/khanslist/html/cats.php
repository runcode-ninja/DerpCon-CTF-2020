<?php
session_start();
$include_functions = True;
require_once('functions.php');
$categories = get_categories();
if (!isset($_GET['cat'])) {
	$cat = NULL;
} else {
	$cat = $_GET['cat'];
}
$listings = get_listings($cat);
$page = $cat;
require __DIR__. '/../vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/../templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('cats.html', ['session_data' => $_SESSION, 'categories' => $categories, 'page' => $page, 'listings' => $listings]);