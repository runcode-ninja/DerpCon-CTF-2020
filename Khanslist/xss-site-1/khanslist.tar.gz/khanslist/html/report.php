<?php
session_start();
if (!isset($_SESSION['userid'])) {
	header('Location: /login.php?msg_type=error&msg=RAWR%20LOGIN%20FIRST');
}
$include_functions = True;
require_once('functions.php');
$messages = array();
if (isset($_GET['listing_id'])) {
	$listing_id = $_GET['listing_id'];
} else {
	$listing_id = False;
	array_push($messages,array("type"=>"error","message"=>"RAWR NO LISTING ID"));
}
if (isset($_POST['do_report_ad'])) {
	$status = report_ad($listing_id,$_POST['report_description']);
	array_push($messages,$status);
}
$categories = get_categories();
$page = 'report';
require __DIR__. '/../vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/../templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('report.html', ['session_data' => $_SESSION, 'categories' => $categories, 'page' => $page, 'listing_id'=>$listing_id,'messages'=>$messages]);