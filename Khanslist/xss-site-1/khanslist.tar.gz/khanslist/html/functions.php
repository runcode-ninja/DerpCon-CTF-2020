<?php

if (!isset($include_functions)) {
	die("Direct access not allowed, This isn't the way, anyways");
}

$sql_username = "root";
$sql_password = "passwordhere";
$sql_host = "127.0.0.1";
$sql_db = "khanslist";

function get_db() {
	global $sql_host,$sql_username,$sql_password,$sql_db;
	$conn = new mysqli($sql_host,$sql_username,$sql_password,$sql_db);
	$conn->set_charset("utf8mb4");
	if ($conn->connect_errno) {
		echo "failed to conn";
		die();
	} else {
		return $conn;
	}
}

function get_categories() {
	$res = array();
	$conn = get_db();
	$query = $conn->prepare("SELECT id,name,description FROM categories ORDER BY id ASC");
	$query->execute();
	$qres = $query->get_result();
	while ($row = $qres->fetch_assoc()) {
		array_push($res,$row);
	}
	return $res;
}

function get_listing($listing_id) {
	$res = array();
	$conn = get_db();

	$query = $conn->prepare("SELECT users.email AS email,listings.id,listings.category AS category_id, categories.name AS category,listings.title,listings.content,listings.image FROM listings,users,categories WHERE listings.id = ? AND listings.userid = users.id AND listings.category = categories.id LIMIT 1");
	$query->bind_param("i",$listing_id);
	$query->execute();
	$qres = $query->get_result();
	$row = $qres->fetch_assoc();
	return $row;
}

function remove_report($report_id) {
	$listing_id = get_report($report_id)['listing_id'];
	$conn = get_db();
	//$stmt = $conn->prepare("DELETE FROM listings WHERE id = ? LIMIT 1");
	//$stmt->bind_param("i",$report_id);
	//$stmt->execute();
	$stmt = $conn->prepare("UPDATE reports SET is_read = 1 WHERE id = ? LIMIT 1");
	$stmt->bind_param("i",$report_id);
	$stmt->execute();


}

function get_report($report_id) {
	$conn = get_db();
	$query = $conn->prepare("SELECT reports.id, reports.listing_id, reports.report_description, users.email AS email, listings.title, listings.id AS listing_id FROM reports,users,listings WHERE reports.userid = users.id AND reports.listing_id = listings.id AND reports.id = ? LIMIT 1");
	$query->bind_param("i",$report_id);
	$query->execute();
	$qres = $query->get_result();
	$row = $qres->fetch_assoc();
	return $row;
}

function get_reports() {
	$res = array();
	$conn = get_db();
	$query = $conn->prepare("SELECT reports.id, reports.listing_id,reports.report_description, users.email AS email,listings.title AS title FROM reports,users,listings WHERE reports.is_read = 0 AND reports.userid = users.id AND reports.listing_id = listings.id ORDER BY reports.id ASC");
	$query->execute();
	$qres = $query->get_result();
	while ($row = $qres->fetch_assoc()) {
		array_push($res,$row);
	}
	return $res;
}


function get_listings($category=False) {
	$res = array();
	$conn = get_db();
	if (!$category) {
		$query = $conn->prepare("SELECT users.email AS email,listings.id,listings.category AS category_id, categories.name AS category,listings.title,listings.content,listings.image FROM listings,users,categories WHERE listings.userid = users.id AND listings.category = categories.id ORDER BY listings.id DESC");
	} else {
		$query = $conn->prepare("SELECT users.email AS email,listings.id,listings.category AS category_id, categories.name AS category,listings.title,listings.content,listings.image FROM listings,users,categories WHERE categories.id = ? AND listings.userid = users.id AND listings.category = categories.id ORDER BY listings.id DESC");
		$query->bind_param("i",$category);
	}
	$query->execute();
	$qres = $query->get_result();
	while ($row = $qres->fetch_assoc()) {
		array_push($res,$row);
	}
	return $res;
}

function report_ad($listing_id,$report_description) {
	$res = array();
	$listing_data = get_listing($listing_id);
	if (!$listing_data) {
		$res = array("type"=>"error","message"=>"RAWR THAT IS NOT A VALID LISTING ID");
	}
	$conn = get_db();
	$userid = $_SESSION['userid'];
	$stmt = $conn->prepare("INSERT INTO reports (userid, listing_id,report_description) VALUES (?,?,?)");
	$stmt->bind_param("iis",$userid,$listing_id,$report_description);
	$stmt->execute();
	$res = array("type"=>"success","message"=>"ROAR YOUR REPORT HAS BEEN NOTED, WILL CHECK IT SHORTLY");
	return $res;
}

function post_ad($ad_title,$ad_description,$ad_category,$ad_img) {
	$res = array();
	if (strlen($ad_title) == 0) {
		array_push($res,array("type"=>"error","message"=>"RAWR NEEDZ A TITLE"));
	}
	if (strlen($ad_description) == 0) {
		array_push($res,array("type"=>"error","message"=>"RAWR NEEDZ A DESCRIPTION"));
	}
	$categories = get_categories();
	$category_ids = array();
	$category_id = intval($ad_category);
	foreach ($categories as $cat) {
		array_push($category_ids,$cat["id"]);
	}
	if (!in_array($category_id,$category_ids)) {
		array_push($res,array("type"=>"warning","message"=>"RAWR UNKNOWN CATEGORY SO IS OTHERS NOW"));
	}
	$userid = $_SESSION['userid'];
	$conn = get_db();
	$stmt = $conn->prepare("INSERT INTO listings (userid,category,title,content,image) VALUES (?,?,?,?,?)");
	$stmt->bind_param("sssss",$userid,$category_id,$ad_title,$ad_description,$ad_img);
	$stmt->execute();
	array_push($res,array("type"=>"success","message"=>"RAWR AD HAS BEEN POSTED"));	

	return $res;
}

function check_register($email,$password) {
	$res = array();
	$email = trim($email);
	$password = trim($password);
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		array_push($res, array("type"=>"error","message"=>"ROAR INVALID EMAIL"));
		return $res;
	}
	// check if it's in the db
	$conn = get_db();
	$query = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
	$query->bind_param("s",$email);
	$query->execute();
	$qres = $query->get_result();
	if ($qres->num_rows > 0) {
		array_push($res, array("type"=>"error","message"=>"ROAR EMAIL ALREADY IN USE"));
		return $res;
	}
	// they actually put in a password
	if (strlen($password) == 0) {
		array_push($res, array("type"=>"error","message"=>"ROAR PASSWORD CANNOT BE BLANK"));
		return $res;
	}
	$password = password_hash($password, PASSWORD_DEFAULT);
	$stmt = $conn->prepare("INSERT INTO users (email,password,admin) VALUES (?,?,0)");
	$stmt->bind_param("ss",$email,$password);
	$stmt->execute();
	array_push($res,array("type"=>"success","message"=>"ROAR ACCOUNT CREATED, LOGIN NAO"));
	return $res;
}

function check_login($email,$password) {
	$conn = get_db();
	$query = $conn->prepare("SELECT id,email,password,admin FROM users WHERE email = ? LIMIT 1");
	$query->bind_param("s",$email);
	$query->execute();
	$res = $query->get_result();
	$row = $res->fetch_assoc();
	if ($row){
		if (password_verify($password,$row["password"])) {
			$_SESSION["userid"] = $row["id"];
			if ($row["admin"] > 0) {
				$_SESSION["admin"] = True;
			} else {
				$_SESSION["admin"] = False;
			}
		return True;
		} else {
			return False;
		}
	}
}
