<?php $flag = 'derp{XSS_2_B_ADMIN_d3RpM13573R}';
