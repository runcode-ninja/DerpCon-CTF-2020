<?php
session_start();
if (!isset($_SESSION['userid'])) {
	header('Location: /login.php?msg_type=error&msg=RAWR%20NOT%20LOGGED%20IN');
	die();
}
if (!$_SESSION['admin']) {
	header('Location: /login.php?msg_type=error&msg=RAWR%20NOT%20AN%20ADMIN');
	die();
}
$messages = array();
$include_functions = True;
require_once('flag.php');
require_once('functions.php');
$categories = get_categories();

if (isset($_GET['cat'])) {
	$page = $_GET['cat'];
} else {
	$page = 'admin';
}

if (isset($_GET['del_report'])) {
	remove_report($_GET['del_report']);
}
$reports = get_reports();
if (isset($_POST['edit_user'])) {
	if ($_POST['userid'] != 1) {
		$user_info = get_user($_SESSION['userid']);
		if ($_SERVER['REMOTE_ADDR'] == $user_info['safe_ip']) {
			$userid = $_POST['userid'];
			$email = $_POST['email'];
			$safe_ip = $_POST['safe_ip'];
			$admin = $_POST['admin'];
			update_user($userid,$email,$safe_ip,$admin);
		} else {
			array_push($messages, array('type'=>'error','message'=>'RAWR THAT IS NOT YOUR SAFE IP!!!'));
		}
	} else {
		array_push($messages,array('type'=>'error','message'=>'RAWR CANNOT UPDATE ADMIN USER ADMIN'));
	}
}

$users = get_users();
require __DIR__. '/../vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/../templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('admin.html', ['session_data' => $_SESSION, 'categories' => $categories, 'page' => $page, 'reports' => $reports,'flag'=>$flag,'users'=>$users,'messages'=>$messages]);