<?php
session_start();
$include_functions = True;
require_once('functions.php');
$categories = get_categories();
$page = "login";
$messages = array();
if (isset($_GET['msg_type']) && (isset($_GET['msg']))) {
	array_push($messages,array("type"=>$_GET['msg_type'],"message"=>$_GET['msg']));
}
if (isset($_POST['do_login'])) {
	$login_status = check_login($_POST['email'],$_POST['password']);
	if (!$login_status) {
		array_push($messages,array("type"=>"error","message"=>"ROAR, INVALID CREDS"));
	} else {
		header('Location: /');
		die();
	}
} elseif (isset($_POST['do_reg'])) {
	$messages = check_register($_POST['email'], $_POST['password']);
}

require __DIR__. '/../vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/../templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('login.html', ['session_data' => $_SESSION, 'categories' => $categories, 'messages' => $messages, 'page' => $page]);