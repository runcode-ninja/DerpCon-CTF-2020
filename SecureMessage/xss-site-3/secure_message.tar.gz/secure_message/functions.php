<?php



$sql_username = "root";
$sql_password = "passwordhere";
$sql_host = "127.0.0.1";
$sql_db = "secure_message";

function get_db() {
	global $sql_host,$sql_username,$sql_password,$sql_db;
	$conn = new mysqli($sql_host,$sql_username,$sql_password,$sql_db);
	$conn->set_charset("utf8mb4");
	if ($conn->connect_errno) {
		echo "failed to conn";
		die();
	} else {
		return $conn;
	}
}

function register($username,$password) {
	$res = array();
	$username = trim($username);
	$password = trim($password);

	// check if it's in the db
	$conn = get_db();
	$query = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
	$query->bind_param("s",$username);
	$query->execute();
	$qres = $query->get_result();
	if ($qres->num_rows > 0) {
		return array("error"=>True,"message"=>"Username Taken");
	}
	// they actuall pyt in a username
	if (strlen($username) == 0) {
		return array("error"=>True,"message"=>"Password is mandatory");
		return $res;
	}
	// they actually put in a password
	if (strlen($password) == 0) {
		return array("error"=>True,"message"=>"Password is mandatory");
	}
	$stmt = $conn->prepare("INSERT INTO users (username,password) VALUES (?,?)");
	$stmt->bind_param("ss",$username,$password);
	$stmt->execute();
	send_welcome($username);
	return array("error"=>False,"message"=>"Registratation success!");
}

function login($username,$password) {
	$conn = get_db();
	$query = $conn->prepare("SELECT id,username,password,admin FROM users WHERE username = ? LIMIT 1");
	$query->bind_param("s",$username);
	$query->execute();
	$res = $query->get_result();
	$row = $res->fetch_assoc();
	if ($row){
		if ($password === $row["password"]) {
			$_SESSION["userid"] = $row["id"];
			$_SESSION["username"] = $row["username"];
			if ($row["admin"] > 0) {
				$_SESSION["admin"] = True;
			} else {
				$_SESSION["admin"] = False;
			}
		return True;
		} else {
			return False;
		}
	}
}
function logged_in() {
	if (isset($_SESSION['userid'])) {
		return True;
	}
	return False;
}

function clean($data) {
	return str_ireplace("<script>","",$data);
}

function send_welcome($username) {
	$subject = "Welcome To SecureMessage(tm)!";
	$message = "This is an automated message to get you started. See how it appears to you? It will disappear as soon as you've read it!";
	$from = 1;
	$to = get_user($username)["id"];
	$conn = get_db();
	$stmt = $conn->prepare("INSERT INTO messages(from_user,to_user,subject,content) VALUES(?,?,?,?)");
	$stmt->bind_param("iiss",$from,$to,$subject,$message);
	$stmt->execute();
}

function send_message($to_username,$message_subject,$message_content) {
	$to_user = get_user($to_username);
	if (!$to_user) {
		return array('error'=>True,'message'=>"Unknown User: " . $to_username);
	}
	$to_userid = $to_user['id'];
	$from_user = $_SESSION['userid'];
	$message_subject = clean($message_subject);
	$conn = get_db();
	$stmt = $conn->prepare("INSERT INTO messages(from_user,to_user,subject,content) VALUES (?,?,?,?)");
	if (!$stmt->bind_param("iiss",$from_user,$to_userid,$message_subject,$message_content)) {
		return array('error'=>True,'message'=>$stmt->error);
	}
	if (!$stmt->execute()) {
		return array('error'=>True,'message'=>$stmt->error);
	}
	return array('error'=>False,'message'=>"Message sent to User: " . $to_username);
} 

function get_messages() {
	$res = array();
	$conn = get_db();
	$query = $conn->prepare("SELECT messages.id,from_user,to_user,subject,is_read,users.username AS username FROM messages,users
							 WHERE to_user = ? AND users.id = from_user AND is_read = 0 ORDER BY messages.id DESC");
	$query->bind_param("s",$_SESSION['userid']);
	$query->execute();
	$qres = $query->get_result();
	while ($row = $qres->fetch_assoc()) {
		array_push($res,$row);
	}
	return $res;
}

function mark_read($message_id) {
	if ($message_id < 2) {
		return 1;
	}
	$conn = get_db();
	$stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ? LIMIT 1");
	$stmt->bind_param("i",$message_id);
	$stmt->execute();
}

function get_message($message_id) {
	$conn = get_db();
	$query = $conn->prepare("SELECT messages.id,from_user,to_user,subject,content,is_read,users.username AS username FROM messages,users WHERE messages.id = ? AND users.id = from_user AND to_user = ? LIMIT 1");
	$query->bind_param("ii",$message_id,$_SESSION['userid']);
	$query->execute();
	$res = $query->get_result();
	$row = $res->fetch_assoc();
	$row['content'] = htmlspecialchars($row['content']);
	mark_read($row['id']);
	return $row;
}
function get_user($username) {
	$conn = get_db();
	$query = $conn->prepare("SELECT id,username,password,admin FROM users WHERE username = ? LIMIT 1");
	$query->bind_param("s",$username);
	$query->execute();
	$res = $query->get_result();
	$row = $res->fetch_assoc();
	return $row;
}