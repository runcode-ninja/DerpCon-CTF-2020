<?php
session_start();
require_once('functions.php');

// handle get_messages
if (isset($_POST['get_messages'])) {
	$res = array();
	if (!logged_in()) {
		$res = array('error'=>True,'message'=>'Not logged in!');
		echo json_encode($res); die();
	} else {
		// get their messages
		$res = get_messages();
		echo json_encode($res); die();
	}
}
// end messages
// handle get_message($message_id)
if (isset($_POST['get_message'])) {
	$res = array();
	if (!logged_in()) {
		$res = array('error'=>True,'message'=>'Not logged in!');
		echo json_encode($res); die();
	} else {
		$res = get_message($_POST['message_id']);
		echo json_encode($res); die();
	}
}
// end get message
// handle send message
if (isset($_POST['send_message'])) {
	if (!logged_in()) {
		$res = array('error'=>True,'message'=>'Not logged in!');
		echo json_encode($res); die();
	} else {
		$res = send_message($_POST['message_to'],$_POST['message_subject'],$_POST['message_content']);
		echo json_encode($res); die();
	}
}

// end send message
// handle register
if (isset($_POST['submit_register'])) {
	$res = array();
	echo json_encode(register($_POST['username'],$_POST['password'])); die();
}
// end register
// handle login
if (isset($_POST['submit_login'])) {
	$res = array();
	if(login($_POST['username'],$_POST['password'])) {
		$res = array('error'=>False,'message'=>'Successfully logged in!');
	} else {
		$res = array('error'=>True,'message'=>'Failed login!');
	}
	echo json_encode($res); die();
}
// end login
// handle logout
if (isset($_POST['submit_logout'])) {
	session_destroy();
	echo json_encode(array('error'=>False)); die();
}
// end logout

require __DIR__. '/vendor/autoload.php';

$loader = new Twig\Loader\FilesystemLoader(__DIR__.'/templates');
$twig = new \Twig\Environment($loader);

echo $twig->render('index.html', ['session_data' => $_SESSION]);